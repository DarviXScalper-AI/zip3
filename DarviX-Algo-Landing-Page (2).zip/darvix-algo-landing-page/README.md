# DarviX Algo Landing Page

## Files
- index.html
- css/style.css
- js/script.js
- images/testimonials/
- images/flyers/

## First edits to make

### 1. WhatsApp
In `index.html`, replace:
`[INSERT WHATSAPP LINK]`

### 2. Class information
Replace:
- `[INSERT CLASS DATE]`
- `[INSERT CLASS TIME]`
- `[INSERT CLASS FORMAT]`

For the countdown, change:
`data-countdown-date="[INSERT CLASS ISO DATE]"`

to a real ISO date, e.g.:
`data-countdown-date="2026-10-15T19:00:00+01:00"`

### 3. Testimonials
Put real screenshot images in:
`images/testimonials/`

Then uncomment/add entries in the `TESTIMONIALS` array in `js/script.js`.

### 4. Flyers
Put real flyers in:
`images/flyers/`

Then uncomment/add entries in the `FLYERS` array in `js/script.js`.

### 5. Preview gallery
The current preview cards are CSS visuals so the page works immediately.
If you have real screenshots, add them by changing the `data-src` on the preview buttons in `index.html`.

## Important
Do not add fabricated testimonials, performance claims, profits, win rates, community counts, scarcity, or credentials.
