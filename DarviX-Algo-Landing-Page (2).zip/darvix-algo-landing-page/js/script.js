/* ============================================================
   DARVIX ALGO — JAVASCRIPT
   Beginner-friendly editing area.
   ============================================================ */

document.addEventListener("DOMContentLoaded", () => {
  /* ==========================================================
     EDIT WHATSAPP LINK HERE
     ========================================================== */
  const WHATSAPP_LINK = window.DARVIX_WHATSAPP_LINK || "[INSERT WHATSAPP LINK]";

  document.querySelectorAll("[data-whatsapp]").forEach((link) => {
    link.href = WHATSAPP_LINK;
    if (WHATSAPP_LINK.startsWith("http")) {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
  });

  /* ==========================================================
     MOBILE NAVIGATION
     ========================================================== */
  const navToggle = document.querySelector(".nav-toggle");
  const mainNav = document.querySelector(".main-nav");

  navToggle?.addEventListener("click", () => {
    const isOpen = mainNav.classList.toggle("open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
  });

  mainNav?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      mainNav.classList.remove("open");
      navToggle?.setAttribute("aria-expanded", "false");
    });
  });

  /* ==========================================================
     REAL COUNTDOWN
     EDIT THE data-countdown-date ATTRIBUTE IN index.html
     Example:
     data-countdown-date="2026-10-15T19:00:00+01:00"
     ========================================================== */
  const countdown = document.querySelector("[data-countdown-date]");
  if (countdown) {
    const dateValue = countdown.dataset.countdownDate;
    const isPlaceholder = !dateValue || dateValue.includes("[INSERT");

    const units = {
      days: countdown.querySelector("[data-days]"),
      hours: countdown.querySelector("[data-hours]"),
      minutes: countdown.querySelector("[data-minutes]"),
      seconds: countdown.querySelector("[data-seconds]")
    };

    const note = countdown.parentElement.querySelector(".countdown-note");

    if (isPlaceholder || Number.isNaN(Date.parse(dateValue))) {
      if (note) note.textContent = "Add a real class date in index.html to activate the countdown.";
    } else {
      const target = new Date(dateValue).getTime();

      const updateCountdown = () => {
        const distance = target - Date.now();

        if (distance <= 0) {
          units.days.textContent = "00";
          units.hours.textContent = "00";
          units.minutes.textContent = "00";
          units.seconds.textContent = "00";
          if (note) note.textContent = "The session time has arrived.";
          return;
        }

        const days = Math.floor(distance / 86400000);
        const hours = Math.floor((distance % 86400000) / 3600000);
        const minutes = Math.floor((distance % 3600000) / 60000);
        const seconds = Math.floor((distance % 60000) / 1000);

        units.days.textContent = String(days).padStart(2, "0");
        units.hours.textContent = String(hours).padStart(2, "0");
        units.minutes.textContent = String(minutes).padStart(2, "0");
        units.seconds.textContent = String(seconds).padStart(2, "0");
      };

      updateCountdown();
      setInterval(updateCountdown, 1000);
    }
  }

  /* ==========================================================
     SCROLL REVEAL ANIMATIONS
     ========================================================== */
  const revealItems = document.querySelectorAll(".reveal");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (reducedMotion) {
    revealItems.forEach((item) => item.classList.add("visible"));
  } else {
    const observer = new IntersectionObserver(
      (entries, obs) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            obs.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    revealItems.forEach((item) => observer.observe(item));
  }

  /* ==========================================================
     TESTIMONIALS
     TO ADD A TESTIMONIAL:
     1. Put the real screenshot in /images/testimonials/
     2. Add an object below.
     3. Do NOT invent testimonials or results.
     ========================================================== */
  const TESTIMONIALS = [
    // { image: "images/testimonials/testimonial1.jpg", alt: "Real learner feedback screenshot" },
    // { image: "images/testimonials/testimonial2.jpg", alt: "Real learner feedback screenshot" },
    // { image: "images/testimonials/testimonial3.jpg", alt: "Real learner feedback screenshot" },
  ];

  const testimonialTrack = document.querySelector("#testimonialTrack");
  const testimonialDots = document.querySelector("#testimonialDots");
  const testimonialEmpty = document.querySelector("#testimonialEmpty");
  const prevTestimonial = document.querySelector(".testimonial-carousel .prev");
  const nextTestimonial = document.querySelector(".testimonial-carousel .next");

  let testimonialIndex = 0;
  let testimonialTimer = null;
  let testimonialStartX = 0;
  let testimonialDragging = false;

  function getSlidesPerView() {
    if (window.innerWidth <= 560) return 1;
    if (window.innerWidth <= 800) return 2;
    return 3;
  }

  function renderTestimonials() {
    if (!testimonialTrack) return;

    testimonialTrack.innerHTML = "";
    testimonialDots.innerHTML = "";

    if (!TESTIMONIALS.length) {
      testimonialEmpty.hidden = false;
      prevTestimonial.hidden = true;
      nextTestimonial.hidden = true;
      return;
    }

    testimonialEmpty.hidden = true;
    prevTestimonial.hidden = false;
    nextTestimonial.hidden = false;

    TESTIMONIALS.forEach((item, index) => {
      const card = document.createElement("article");
      card.className = "testimonial-card";
      card.innerHTML = `<img src="${item.image}" alt="${item.alt || "Testimonial screenshot"}" loading="lazy">`;
      testimonialTrack.appendChild(card);

      const dot = document.createElement("button");
      dot.type = "button";
      dot.className = "carousel-dot";
      dot.setAttribute("aria-label", `Go to testimonial ${index + 1}`);
      dot.addEventListener("click", () => {
        testimonialIndex = index;
        updateTestimonials();
        restartTestimonialTimer();
      });
      testimonialDots.appendChild(dot);
    });

    testimonialIndex = Math.min(testimonialIndex, Math.max(0, TESTIMONIALS.length - getSlidesPerView()));
    updateTestimonials();
    startTestimonialTimer();
  }

  function updateTestimonials() {
    if (!testimonialTrack || !TESTIMONIALS.length) return;

    const cards = testimonialTrack.querySelectorAll(".testimonial-card");
    if (!cards.length) return;

    const gap = 17;
    const cardWidth = cards[0].getBoundingClientRect().width;
    testimonialTrack.style.transform = `translateX(-${testimonialIndex * (cardWidth + gap)}px)`;

    const dots = testimonialDots.querySelectorAll(".carousel-dot");
    const maxIndex = Math.max(0, TESTIMONIALS.length - getSlidesPerView());
    dots.forEach((dot, index) => {
      dot.classList.toggle("active", index === Math.min(testimonialIndex, maxIndex));
    });
  }

  function moveTestimonials(direction) {
    if (!TESTIMONIALS.length) return;
    const maxIndex = Math.max(0, TESTIMONIALS.length - getSlidesPerView());
    testimonialIndex += direction;
    if (testimonialIndex > maxIndex) testimonialIndex = 0;
    if (testimonialIndex < 0) testimonialIndex = maxIndex;
    updateTestimonials();
    restartTestimonialTimer();
  }

  function startTestimonialTimer() {
    if (reducedMotion || TESTIMONIALS.length < 2) return;
    clearInterval(testimonialTimer);
    testimonialTimer = setInterval(() => moveTestimonials(1), 5000);
  }

  function restartTestimonialTimer() {
    clearInterval(testimonialTimer);
    startTestimonialTimer();
  }

  prevTestimonial?.addEventListener("click", () => moveTestimonials(-1));
  nextTestimonial?.addEventListener("click", () => moveTestimonials(1));

  testimonialTrack?.addEventListener("pointerdown", (event) => {
    testimonialDragging = true;
    testimonialStartX = event.clientX;
    testimonialTrack.setPointerCapture?.(event.pointerId);
  });

  testimonialTrack?.addEventListener("pointerup", (event) => {
    if (!testimonialDragging) return;
    testimonialDragging = false;
    const delta = event.clientX - testimonialStartX;
    if (Math.abs(delta) > 45) moveTestimonials(delta < 0 ? 1 : -1);
  });

  testimonialTrack?.addEventListener("pointercancel", () => {
    testimonialDragging = false;
  });

  window.addEventListener("resize", updateTestimonials);
  renderTestimonials();

  /* ==========================================================
     FLYER GALLERY
     TO ADD A FLYER:
     1. Put the real flyer in /images/flyers/
     2. Add an object below.
     ========================================================== */
  const FLYERS = [
    // { image: "images/flyers/flyer1.jpg", alt: "DarviX training flyer", caption: "Upcoming DarviX training" },
    // { image: "images/flyers/flyer2.jpg", alt: "DarviX master class flyer", caption: "Synthetic Indices Master Class" },
    // { image: "images/flyers/flyer3.jpg", alt: "DarviX learning session flyer", caption: "DarviX educational session" },
  ];

  const flyerGrid = document.querySelector("#flyerGrid");
  const flyerEmpty = document.querySelector("#flyerEmpty");

  if (FLYERS.length) {
    flyerEmpty.hidden = true;
    FLYERS.forEach((item, index) => {
      const button = document.createElement("button");
      button.className = "flyer-card reveal";
      button.type = "button";
      button.dataset.lightbox = "flyer";
      button.dataset.src = item.image;
      button.dataset.caption = item.caption || "";
      button.innerHTML = `<img src="${item.image}" alt="${item.alt || "DarviX flyer"}" loading="lazy">`;
      flyerGrid.appendChild(button);
    });
  }

  /* ==========================================================
     LIGHTBOX
     Works for flyers and any media card with a valid data-src.
     ========================================================== */
  const lightbox = document.querySelector("#lightbox");
  const lightboxImage = document.querySelector("#lightboxImage");
  const lightboxCaption = document.querySelector("#lightboxCaption");
  const lightboxClose = document.querySelector(".lightbox-close");
  const lightboxPrev = document.querySelector(".lightbox-prev");
  const lightboxNext = document.querySelector(".lightbox-next");

  let lightboxItems = [];
  let lightboxIndex = 0;

  function refreshLightboxItems(group) {
    lightboxItems = [...document.querySelectorAll(`[data-lightbox="${group}"][data-src]`)]
      .filter((item) => item.dataset.src);
  }

  function openLightbox(element) {
    const group = element.dataset.lightbox;
    refreshLightboxItems(group);
    lightboxIndex = Math.max(0, lightboxItems.indexOf(element));
    showLightboxItem();
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.classList.add("lightbox-open");
  }

  function showLightboxItem() {
    const item = lightboxItems[lightboxIndex];
    if (!item) return;
    lightboxImage.src = item.dataset.src;
    lightboxImage.alt = item.querySelector("img")?.alt || item.dataset.caption || "DarviX visual";
    lightboxCaption.textContent = item.dataset.caption || "";
    const hasMultiple = lightboxItems.length > 1;
    lightboxPrev.hidden = !hasMultiple;
    lightboxNext.hidden = !hasMultiple;
  }

  function closeLightbox() {
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden", "true");
    document.body.classList.remove("lightbox-open");
    setTimeout(() => { lightboxImage.src = ""; }, 200);
  }

  document.addEventListener("click", (event) => {
    const media = event.target.closest("[data-lightbox][data-src]");
    if (media && media.dataset.src) openLightbox(media);
  });

  lightboxClose?.addEventListener("click", closeLightbox);
  lightbox?.addEventListener("click", (event) => {
    if (event.target === lightbox) closeLightbox();
  });

  lightboxPrev?.addEventListener("click", () => {
    if (!lightboxItems.length) return;
    lightboxIndex = (lightboxIndex - 1 + lightboxItems.length) % lightboxItems.length;
    showLightboxItem();
  });

  lightboxNext?.addEventListener("click", () => {
    if (!lightboxItems.length) return;
    lightboxIndex = (lightboxIndex + 1) % lightboxItems.length;
    showLightboxItem();
  });

  document.addEventListener("keydown", (event) => {
    if (!lightbox.classList.contains("open")) return;
    if (event.key === "Escape") closeLightbox();
    if (event.key === "ArrowLeft") lightboxPrev.click();
    if (event.key === "ArrowRight") lightboxNext.click();
  });

  /* ==========================================================
     FOOTER YEAR
     ========================================================== */
  document.querySelector("#year").textContent = new Date().getFullYear();
});
